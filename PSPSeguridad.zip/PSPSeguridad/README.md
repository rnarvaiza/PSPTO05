
# PSP TO 05 Seguridad - RegEx -

### Implementación de expresiones regulares.

Uso de matcher & pattern, expresiones regulares, patrones.

### FileWriter & FileReader

Creador de ficheros y lector de ficheros.

### Logger

Creación de logs mostrando los eventos más importantes con diferentes niveles de alerta.

### Implementación de try-with-resources

Instanciación de las clases que implementan la interfaz "autocloseable" en modo try with resources.  
[API java 11](https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/lang/AutoCloseable.html)  
[Best practices java stackify](https://stackify.com/best-practices-exceptions-java/)